var DEFAULT_IMAGE_PATH = "http://doypaxk1e2349.cloudfront.net/icons/user-default.png";
var DEFAULT_LOGIN_NAME = "My Account";

$(document).ready(function() {
    if (typeof jQuery(document).fancybox === "function") {
        var feedbackbutton = '<a href="/promotions/feedback/feedback.htm" class="various fancybox.ajax"><img style="position:fixed;right:0;top:0;bottom:0;margin:auto 0;" src="http://b12984e4d8c82ca48867-a8f8a87b64e178f478099f5d1e26a20d.r85.cf1.rackcdn.com/feedback.png" /></a>';
        $("body").append(feedbackbutton);
    }
    update_ui();
    countPages();
    getAutopopupURL($(".auto-popup-data"));
    var subcategory = $('#msp_body').attr('category');
    $.ajax({
        type: 'GET',
        url: "http://www.mysmartprice.com/msp/deals/rightsidebar_json.php?subcategory=" + subcategory,
        dataType: 'json',
        success: function(data) {
            $.each(data, function(index, item) {
                if ($("#" + item.id).length > 0) {
                    $("#" + item.id).append(item.content);
                }
            });
        },
    });
    $("#olx_banner").load("/promotions/ads/olx_banner.htm");
    var loc = window.location.href;
    if ($(".product_bottom_sec").length) {
        if (loc.indexOf("view_all") > 0 && loc.indexOf("alternatives") > 0) {
            $("html, body").animate({
                scrollTop: ($(".product_bottom_sec").position().top - 50) + "px"
            });
        }
    }
});
var loginCallbackQueue = [];

function loginCallback(fn, context, params) {
    if (getCookie("msp_login") == "1")
        fn.apply(context, params);
    else {
        loginCallbackQueue.push(function() {
            fn.apply(context, params);
        });
        $(".login-button").click();
    }
}
try {
    $(".various").fancybox({
        fitToView: false,
        width: "auto",
        height: "auto",
        padding: 10,
        beforeClose: function() {
            setTimeout(function() {
                if (getCookie("msp_login") != "1" && !$(".fancybox-overlay").filter(":visible").length)
                    loginCallbackQueue = [];
            }, 1000);
        }
    });
} catch (err) {
    console.log("Error in JS for fancybox");
}

function update_ui() {
    var msp_login = getCookie("msp_login"),
        msp_user_image = getCookie("msp_user_image"),
        msp_login_name = getCookie("msp_login_name") || getCookie("msp_login_email");
    if (msp_login == "1") {
        $(".lgn-rgstr").hide();
        $(".usr-lgt").show();
        $(".js-usr-name").text(msp_login_name);
        if (msp_user_image)
            $(".usr-img").attr("src", msp_user_image);
    } else {
        $(".usr-lgt").hide();
        $(".js-usr-name").text(DEFAULT_LOGIN_NAME);
        $(".usr-img").attr("src", DEFAULT_IMAGE_PATH);
        $(".lgn-rgstr").show();
    }
}

function loginme(msg) {
    setCookie("msp_login", "1", 365);
    if (msg.indexOf(",") > -1) {
        var responseInfo = msg.split(",");
        setCookie("msp_login_uid", responseInfo[0], 365);
        setCookie("msp_login_email", responseInfo[1], 365);
        msg = responseInfo[1];
    } else
        setCookie("msp_login_email", msg, 365);
    var wiz_uid = get_uid(),
        wiz_msg = '"' + msg + '"';
    wizrocket.profile.push({
        "Site": {
            "Identity": wiz_uid,
            "Email": wiz_msg
        }
    });
    $.get("http://www.mysmartprice.com/users/set_username_cookie.php", {
        email: msg
    }, function(name) {
        setCookie("msp_login_name", name, 365);
    });
    update_ui();
    while (loginCallbackQueue.length)(loginCallbackQueue.shift())();
}

function loginme_by_fb(msg, img) {
    setCookie("msp_user_image", img, 365);
    loginme(msg);
}

function logoutme() {
    setCookie("msp_login", "", -1);
    setCookie("msp_login_email", "", -1);
    setCookie("msp_user_image", "", -1);
    update_ui();
}

function countPages() {
    var number = getCookie("num_pages");
    if (!number) number = 1;
    else number = parseInt(number, 10) + 1;
    setCookie("num_pages", number, 7);
}

function trackLink(category, action, label, value, link) {
    if (typeof(_gaq) === "undefined") return;
    try {
        _gaq.push(["_trackEvent", category, action, label, value]);
    } catch (err) {}
    setTimeout((function() {
        location.href = link;
    }), 400);
    return false;
}
